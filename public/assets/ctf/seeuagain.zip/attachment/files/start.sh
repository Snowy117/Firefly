#!/bin/bash
echo start env