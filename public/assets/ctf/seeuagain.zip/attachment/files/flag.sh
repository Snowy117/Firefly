#!/bin/bash

echo flag{fake_flag} > /flag

chmod 444 /flag

export FLAG=not_flag
FLAG=not_flag

rm -f /flag.sh
